/*
// Below code for Changing th Course Curriculum into Accordion style
 jQuery(document).ready(function(){
   jQuery('.course_curriculum .course_section').click(function(event){
   		jQuery(this).toggleClass('show');
   		jQuery(this).nextUntil('.course_section').toggleClass('show');
   });
   jQuery('.course_timeline .section').click(function(event){
   		jQuery(this).toggleClass('show');
   		jQuery(this).nextUntil('.section').toggleClass('show');
   });
}); */