<?php
//DASH ANNOUNCEMENTS : meta_key wplms_accouncement
//
add_action( 'widgets_init', 'wplms_annoucement_widget' );

function wplms_annoucement_widget() {
    register_widget('wplms_annoucement');
}

class wplms_annoucement extends WP_Widget {

    /** constructor -- name this the same as the class above */
    function wplms_annoucement() {
    $widget_ops = array( 'classname' => 'wplms_annoucement', 'description' => __('Annoucement Widget for Dashboard', 'wplms-dashboard') );
    $control_ops = array( 'width' => 300, 'height' => 350, 'id_base' => 'wplms_annoucement' );
    $this->WP_Widget( 'wplms_annoucement', __(' DASHBOARD : Instructor Annoucement Widget', 'wplms-dashboard'), $widget_ops, $control_ops );
    add_action('wp_ajax_send_annoucements',array($this,'send_annoucements'));
    add_action('bp_before_dashboard_body',array($this,'check_annoucements'));
  }
        
 
    /** @see WP_Widget::widget -- do not rename this */
    function widget( $args, $instance ) {

    extract( $args );
    global $wpdb;
    //Our variables from the widget settings.
    $title = apply_filters('widget_title', $instance['title'] );
    $width =  $instance['width'];
    $user_id = get_current_user_id();

    echo '<div class="'.$width.'">
            <div class="dash-widget">'.$before_widget;

    // Display the widget title 
    if ( $title )
      	echo $before_title . $title . $after_title;
    		
        $query = apply_filters('wplms_dashboard_courses_instructors',$wpdb->prepare("
              SELECT posts.ID as course_id
                FROM {$wpdb->posts} AS posts
                WHERE   posts.post_type   = 'course'
                AND   posts.post_author   = %d
            ",$user_id));

        $instructor_courses=$wpdb->get_results($query,ARRAY_A);
        $annoucements=array();
        if(isset($instructor_courses) && count($instructor_courses)){
          echo '<ul class="my_anouncements">';
          foreach($instructor_courses as $key => $value){
              $course_id=$value['course_id'];
              $course_array[$course_id]=get_the_title($course_id);
              
              $annoucement=get_post_meta($course_id,'annoucement',true);

              if(isset($annoucement) && strlen($annoucement)>5){
                echo '<li><strong>'.$course_array[$course_id].'</strong> '.$annoucement.'<li>';  
              }
          }
          echo '</ul>';
        }
        echo '<textarea id="add_annoucement" placeholder="'.__('Add annoucement','wplms-dashboard').'"></textarea>';
        echo '<select class="chosen" id="course_list" data-placeholder="'.__('Send announcement to student in courses','wplms-dashboard').'"  multiple>';
        foreach($course_array as $key => $value){
          echo '<option value="'.$key.'">'.$value.'</option>';
        }
        echo '</select>';
        echo '<a id="submit_annoucement" class="button">'.__('Submit','wplms-dashboard').'</a>';
        echo $after_widget.'
        </div>
        </div>';
                
    }
 
    /** @see WP_Widget::update -- do not rename this */
    function update($new_instance, $old_instance) {   
	    $instance = $old_instance;
	    $instance['title'] = strip_tags($new_instance['title']);
	    $instance['width'] = $new_instance['width'];
	    return $instance;
    }
 
    /** @see WP_Widget::form -- do not rename this */
    function form($instance) {  
        $defaults = array( 
                        'title'  => __('Annoucement','wplms-dashboard'),
                        'max' => 5,
                        'width' => 'col-md-6 col-sm-12'
                    );
  		  $instance = wp_parse_args( (array) $instance, $defaults );
        $title  = esc_attr($instance['title']);
        $width = esc_attr($instance['width']);
        ?>
        <p>
          <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:','wplms-dashboard'); ?></label> 
          <input class="regular_text" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo $title; ?>" />
        </p>
        </p>
        <p>
          <label for="<?php echo $this->get_field_id('width'); ?>"><?php _e('Select Width','wplms-dashboard'); ?></label> 
          <select id="<?php echo $this->get_field_id('width'); ?>" name="<?php echo $this->get_field_name('width'); ?>">
          	<option value="col-md-3 col-sm-6" <?php selected('col-md-3 col-sm-6',$width); ?>><?php _e('One Fourth','wplms-dashboard'); ?></option>
          	<option value="col-md-4 col-sm-6" <?php selected('col-md-4 col-sm-6',$width); ?>><?php _e('One Third','wplms-dashboard'); ?></option>
          	<option value="col-md-6 col-sm-12" <?php selected('col-md-6 col-sm-12',$width); ?>><?php _e('One Half','wplms-dashboard'); ?></option>
            <option value="col-md-8 col-sm-12" <?php selected('col-md-8 col-sm-12',$width); ?>><?php _e('Two Third','wplms-dashboard'); ?></option>
             <option value="col-md-8 col-sm-12" <?php selected('col-md-9 col-sm-12',$width); ?>><?php _e('Three Fourth','wplms-dashboard'); ?></option>
          	<option value="col-md-12" <?php selected('col-md-12',$width); ?>><?php _e('Full','wplms-dashboard'); ?></option>
          </select>
        </p>
        <?php 
    }

    function send_annoucements(){
      if ( !isset($_POST['security']) || !wp_verify_nonce($_POST['security'],'vibe_security') || !current_user_can('edit_posts')){
             _e('Security error','wplms-dashbaord');
             die();
      }
      global $wpdb;
      $annoucement=$_POST['annoucement'];
      $course_list=$_POST['course_list'];
      if(!isset($annoucement) || strlen($annoucement)< 5){
        _e('Please enter some text for annoucement','wplms-dashbaord');
        die();
      }
      if(!isset($course_list) || !is_array($course_list)){
        _e('Course list not set','wplms-dashbaord');
        die();
      }

      foreach($course_list as $list){
        if(is_numeric($list)){
          update_post_meta($list,'annoucement',$annoucement);
        }
      }
       _e('Annoucement successfully delivered','wplms-dashboard'); 
      die();
    }

    function check_annoucements(){
        global $wpdb;
        $user_id=get_current_user_id();
        $user_courses=$wpdb->get_results($wpdb->prepare("
              SELECT rel.post_id as id,posts.post_title as title
                FROM {$wpdb->posts} AS posts
                LEFT JOIN {$wpdb->postmeta} AS rel ON posts.ID = rel.post_id
                WHERE   posts.post_type   = 'course'
                AND   posts.post_status   = 'publish'
                AND   rel.meta_key   = %d
                AND   rel.meta_value < 2
            ",$user_id),ARRAY_A);
        $annoucements=array();
        if(is_Array($user_courses) && count($user_courses)){
          foreach($user_courses as $course){
            $annoucement = get_post_meta($course['id'],'annoucement',true);
            if(isset($annoucement) && $annoucement){
               $annoucements[]=array(
                'id' => $course['id'],
                'title' => $course['title'],
                'annoucement'=>$annoucement);
            }
          }
        }
        $k=count($annoucements);
        if($k){
          echo '<div class="col-md-12"><div class="annoucement_message message" data-count="'.$k.'">
          <span>'.__('CLICK TO EXPAND','wplms-dashboard').'</span>
          <p>'.sprintf(__('You have %s annoucements','wplms-dashboard'),'<strong>'.$k.'</strong>').'</p>
          <ul class="annoucements">';

          foreach($annoucements as $annoucement){
             echo '<li data-course="'.$annoucement['id'].'"><strong>'.$annoucement['title'].'</strong>'.$annoucement['annoucement'].'<span><i class="icon-x"></i></span></li>';
          }
          echo '</ul>
          </div></div>';
        }
    }
} 

?>